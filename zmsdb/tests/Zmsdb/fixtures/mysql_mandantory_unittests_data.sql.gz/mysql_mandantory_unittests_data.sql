LOCK TABLES `source` WRITE;

INSERT INTO `source` SET `source` = "unittest", `label` = "Unittest Source", `editable` = 1, `contact__name` = "BerlinOnline Stadtportal GmbH", `contact__email` = "zms@berlinonline.de";

UNLOCK TABLES;

LOCK TABLES `provider` WRITE;

INSERT INTO `provider` (`source`, `id`, `name`, `contact__city`, `contact__country`, `contact__lat`, `contact__lon`, `contact__postalCode`, `contact__region`, `contact__street`, `contact__streetNumber`, `link`, `data`) VALUES 
('unittest', '9999998', 'Unittest Source Dienstleister', 'Berlin', 'Germany', '11.1111', '22.2222', '10178', 'Berlin', 'Alte Jakobstraße', 105, 'https://www.berlinonline.de', '{"json":"data"}'), 
('unittest', '9999999', 'Unittest Source Dienstleister 2', 'Berlin', 'Germany', '33.3333', '44.4444', '10178', 'Berlin', 'Alte Jakobstraße', 106, 'https://www.berlinonline.de', '{"json":"data","key":"value"}');

UNLOCK TABLES;

LOCK TABLES `request` WRITE;

INSERT INTO `request` (`source`,`id`,`name`,`link`,`group`,`data`) VALUES 
('unittest','9999998','Unittest Source Dienstleistung','https://www.berlinonline.de','Unittests','{"json":"data"}'),
('unittest','9999999','Unittest Source Dienstleistung 2','https://www.berlinonline.de','Unittests','{"json":"data","key":"value"}');

UNLOCK TABLES;

LOCK TABLES `request_provider` WRITE;

INSERT INTO `request_provider` (`source`,`request__id`,`provider__id`,`slots`) VALUES 
('unittest','9999998','9999998',2),
('unittest','9999998','9999999',1),
('unittest','9999999','9999999',1);

UNLOCK TABLES;


INSERT INTO `buerger` (`BuergerID`, `StandortID`, `Datum`, `Uhrzeit`, `Name`, `Anmerkung`, `Telefonnummer`, `EMail`, `EMailverschickt`, `Erinnerungszeitpunkt`, `SMSverschickt`, `AnzahlAufrufe`, `Timestamp`, `IPAdresse`, `IPTimeStamp`, `NutzerID`, `aufruferfolgreich`, `wsm_aufnahmezeit`, `aufrufzeit`, `wartezeit`, `nicht_erschienen`, `Abholer`, `AbholortID`, `wartenummer`, `vorlaeufigeBuchung`, `hatFolgetermine`, `istFolgeterminvon`, `zustimmung_kundenbefragung`, `telefonnummer_fuer_rueckfragen`, `absagecode`, `AnzahlPersonen`, `updateTimestamp`, `apiClientID`, `bestaetigt`) VALUES
(77770, 141, '2016-04-12', '13:10:00', 'K62352632', '', '', 'zms@service.berlinonline.de', 0, 0, 0, 0, '00:00:00', '127.0.0.1', 1455270113, 0, 0, '00:00:00', '00:00:00', NULL, 0, 0, 0, 0, 0, 0, NULL, 0, '', 'b0b7', 1, '2019-08-23 15:22:16', 1,1),
(77776, 145, '2016-04-12', '08:20:00', 'M300', '', '', 'zms@service.berlinonline.de', 0, 0, 0, 0, '00:00:00', '127.0.0.1', 1458217247, 0, 0, '13:23:19', '00:00:00', NULL, 0, 0, 0, 0, 0, 0, NULL, 0, '', 'd755', 1, '2019-08-23 15:22:16', 1,1),
(77777, 108, '2016-04-06', '10:00:00', 'S150', '', '', 'zms@service.berlinonline.de', 0, 0, 0, 0, '00:00:00', '127.0.0.1', 1455094538, 0, 0, '00:00:00', '00:00:00', NULL, 0, 0, 0, 0, 0, 0, NULL, 0, '', 'a2cb', 1, '2019-08-23 15:22:16', 1,1),
(77778, 101, '2016-04-15', '11:48:00', 'R5261', '', '', 'zms@service.berlinonline.de', 0, 0, 0, 0, '00:00:00', '127.0.0.1', 1455875412, 0, 0, '00:00:00', '00:00:00', NULL, 0, 0, 0, 0, 0, 0, NULL, 0, '', '67d0', 1, '2019-08-23 15:22:16', 1,1),
(77780, 141, '2016-04-19', '14:30:00', 'K545163', '', '', 'zms@service.berlinonline.de', 0, 0, 0, 0, '00:00:00', '127.0.0.1', 1455875422, 0, 0, '00:00:00', '00:00:00', NULL, 0, 0, 0, 0, 0, 0, NULL, 0, '', 'b8c1', 1, '2019-08-23 15:22:16', 1,1);
