LOCK TABLES `source` WRITE;

INSERT INTO `source` SET `source` = "unittest", `label` = "Unittest Source", `editable` = 1, `contact__name` = "BerlinOnline Stadtportal GmbH", `contact__email` = "zms@berlinonline.de";

UNLOCK TABLES;

LOCK TABLES `provider` WRITE;

INSERT INTO `provider` (`source`, `id`, `name`, `contact__city`, `contact__country`, `contact__lat`, `contact__lon`, `contact__postalCode`, `contact__region`, `contact__street`, `contact__streetNumber`, `link`, `data`) VALUES 
('unittest', '9999998', 'Unittest Source Dienstleister', 'Berlin', 'Germany', '11.1111', '22.2222', '10178', 'Berlin', 'Alte Jakobstraße', 105, 'https://www.berlinonline.de', '{"json":"data"}'), 
('unittest', '9999999', 'Unittest Source Dienstleister 2', 'Berlin', 'Germany', '33.3333', '44.4444', '10178', 'Berlin', 'Alte Jakobstraße', 106, 'https://www.berlinonline.de', '{"json":"data","key":"value"}');

UNLOCK TABLES;

LOCK TABLES `request` WRITE;

INSERT INTO `request` (`source`,`id`,`name`,`link`,`group`,`data`) VALUES 
('unittest','9999998','Unittest Source Dienstleistung','https://www.berlinonline.de','Unittests','{"json":"data"}'),
('unittest','9999999','Unittest Source Dienstleistung 2','https://www.berlinonline.de','Unittests','{"json":"data","key":"value"}');

UNLOCK TABLES;

LOCK TABLES `request_provider` WRITE;

INSERT INTO `request_provider` (`source`,`request__id`,`provider__id`,`slots`) VALUES 
('unittest','9999998','9999998',2),
('unittest','9999998','9999999',1),
('unittest','9999999','9999999',1);

UNLOCK TABLES;


UPDATE `buerger` SET `bestaetigt` = 1 WHERE `BuergerID` IN (10118, 10114, 10030,10029);