LOCK TABLES `source` WRITE;

INSERT INTO `source` SET `source` = "unittest", `label` = "Unittest Source", `editable` = 1, `contact__name` = "BerlinOnline Stadtportal GmbH", `contact__email` = "zms@berlinonline.de";

UNLOCK TABLES;

LOCK TABLES `provider` WRITE;

INSERT INTO `provider` (`source`, `id`, `name`, `contact__city`, `contact__country`, `contact__lat`, `contact__lon`, `contact__postalCode`, `contact__region`, `contact__street`, `contact__streetNumber`, `link`, `data`) VALUES 
('unittest', '9999998', 'Unittest Source Dienstleister', 'Berlin', 'Germany', '11.1111', '22.2222', '10178', 'Berlin', 'Alte Jakobstraße', 105, 'https://www.berlinonline.de', '{"json":"data"}'), 
('unittest', '9999999', 'Unittest Source Dienstleister 2', 'Berlin', 'Germany', '33.3333', '44.4444', '10178', 'Berlin', 'Alte Jakobstraße', 106, 'https://www.berlinonline.de', '{"json":"data","key":"value"}');

UNLOCK TABLES;

LOCK TABLES `request` WRITE;

INSERT INTO `request` (`source`,`id`,`name`,`link`,`group`,`data`) VALUES 
('unittest','9999998','Unittest Source Dienstleistung','https://www.berlinonline.de','Unittests','{"json":"data"}'),
('unittest','9999999','Unittest Source Dienstleistung 2','https://www.berlinonline.de','Unittests','{"json":"data","key":"value"}');

UNLOCK TABLES;

LOCK TABLES `request_provider` WRITE;

INSERT INTO `request_provider` (`source`,`request__id`,`provider__id`,`slots`) VALUES 
('unittest','9999998','9999998',2),
('unittest','9999998','9999999',1),
('unittest','9999999','9999999',1);

UNLOCK TABLES;


UPDATE `buerger` SET `bestaetigt` = 1 WHERE `BuergerID` IN (10118, 10114, 10030);


LOCK TABLES `gesamtkalender` WRITE;

INSERT INTO `gesamtkalender` (`scope_id`, `time`,`availability_id` , `seat`, `status`) VALUES
(380, '2016-05-27 09:30:00' ,1330, 1, 'free'),
(380, '2016-05-27 09:35:00' ,1330, 1, 'free'),
(380, '2016-05-27 09:40:00' ,1330, 1, 'free'),
(380, '2016-05-27 09:45:00' ,1330, 1, 'free'),
(380, '2016-05-27 09:50:00' ,1330, 1, 'free');

UNLOCK TABLES;


/* ------------------------------------------------------------------
   Test‑Daten OverallCalendar
-------------------------------------------------------------------*/
LOCK TABLES
  `gesamtkalender` WRITE,
  `oeffnungszeit`  WRITE;

/* --- Scope 1300 ---------------------------------------------------*/
DELETE FROM `gesamtkalender` WHERE scope_id = 1300;
INSERT INTO `gesamtkalender` (scope_id, time, seat, status) VALUES
  (1300,'2016-05-27 09:30:00',1,'free'),
  (1300,'2016-05-27 09:35:00',1,'free');

/* --- Scope 1301 – Availability‑Test ------------------------------*/
DELETE FROM `gesamtkalender` WHERE scope_id = 1301;
DELETE FROM `oeffnungszeit`   WHERE OeffnungszeitID = 999;  /* optional */

INSERT INTO `oeffnungszeit`
  (`OeffnungszeitID`, `StandortID`, `Startdatum`, `Endedatum`,
   `allexWochen`, `jedexteWoche`, `Wochentag`,
   `Anfangszeit`, `Terminanfangszeit`, `Endzeit`, `Terminendzeit`,
   `Timeslot`,
   `Anzahlarbeitsplaetze`, `Anzahlterminarbeitsplaetze`,
   `kommentar`, `reduktionTermineImInternet`, `erlaubemehrfachslots`,
   `reduktionTermineCallcenter`, `Offen_ab`, `Offen_bis`, `updateTimestamp`)
VALUES
  (999,               
   1301,
   '2016-05-27','2016-05-27',
   0,1,32,
   '09:00:00','09:00:00','10:00:00','10:00:00',
   '00:05:00',
   2,2,
   'Unit‑Test Availability',
   0,1,0,
   0,0,
   '2025-05-05 00:00:00');

UNLOCK TABLES;
