LOCK TABLES `source` WRITE;

INSERT INTO `source` SET `source` = "unittest", `label` = "Unittest Source", `editable` = 1, `contact__name` = "BerlinOnline Stadtportal GmbH", `contact__email` = "zms@berlinonline.de";

UNLOCK TABLES;

LOCK TABLES `provider` WRITE;

INSERT INTO `provider` SET `source` = "unittest", `id` = "999999", `name` = "Unittest Source Dienstleister", `contact__city` = "Berlin", `contact__country` = "Germany", `contact__lat` = "11.1111", `contact__lon` = "22.2222", `contact__postalCode` = "10178", `contact__region` = "Berlin", `contact__street` = "Alte Jakobstraße", `contact__streetNumber` = "105", `link` = "https://www.berlinonline.de", `data` = "{'json':'data'}";

UNLOCK TABLES;

LOCK TABLES `request` WRITE;

INSERT INTO `request` SET `source` = "unittest", `id` = "999999", `name` = "Unittest Source Dienstleistung", `link` = "https://www.berlinonline.de", `group` = "Unittests", `data` = "{'json':'data'}";

UNLOCK TABLES;

LOCK TABLES `request_provider` WRITE;

INSERT INTO `request_provider` SET `source` = "unittest", `request__id` = "999999", `provider__id` = "999999", `slots` = 2;

UNLOCK TABLES;